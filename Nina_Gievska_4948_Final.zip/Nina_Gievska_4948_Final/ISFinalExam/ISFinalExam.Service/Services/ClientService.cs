﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Automapper;

namespace ISFinalExam.Service.Services
{
    public class ClientService : IClientService
    {
        private readonly IMapper _mapper;
        private readonly IClientsRepository _clientsRepository;

        public ClientService(IClientsRepository clientRepository, IMapper mapper)
        {
            _clientsRepository = clientRepository;
            _mapper = mapper;
        }

        public IEnumerable<ClientModel> GetClients()
        {
           
            var clients = _clientsRepository.GetClients();
            return _mapper.Map<IEnumerable<ClientModel>>(clients);
        }

        public ClientModel GetClientById(int id)
        {

            var client = _clientRepository.GetClientById(id);
            return _mapper.Map<ClientModel>(client);
        }

        public ClientModel AddClient(ClientModel client)
        {
            Client newClient = _mapper.Map<Client>(client);

            if (_clientsRepository.GetClientById(client.Id) == null)
            {
                _clientsRepository.AddClient(newClient);
            }
            return _mapper.Map<ClientModel>(newClient);
        }

        public ClientModel UpdateClient(ClientModel client)
        {
            Client newClient = _mapper.Map<Client>(client);
            Client oldClient = _clientsRepository.GetClientById(newClient.Id);

            if (oldClient != null)
            {
                _clientsRepository.UpdateClient(oldClient, newClient);
            }
            return _mapper.Map<ClientModel>(newClient);
        }

        public bool DeleteClient(int id)
        {
            var clientEntity = _clientsRepository.GetClientById(id);

           
            return _clientsRepository.DeleteClients(clientEntity);
        }



    }
}
}
