﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Automapper;

namespace ISFinalExam.Service.Services
{
    public class BookService : IBookService
    {
        private readonly IMapper _mapper;
        private readonly IBookRepository _bookRepository;

        public BookService(IBookRepository bookRepository, IMapper mapper)
        {
            _bookRepository = bookRepository;
            _mapper = mapper;
        }

        public BookModel GetBookById(int id)
        {
            var book = _bookRepository.GetBookById(id);
            return _mapper.Map<BookModel>(book);
        }

        public IEnumerable<BookModel> GetBooks()
        {
            var books = _bookRepository.GetBooks();
            return _mapper.Map<IEnumerable<BookModel>>(books);
        }

        public BookModel AddBook(BookModel book)
        {
            Book newBook = _mapper.Map<Book>(book);

            if (_bookRepository.GetBookById(book.Id) == null)
            {
                _bookRepository.AddBook(newBook);
            }
            return _mapper.Map<BookModel>(newBook);
        }

        public BookDTO UpdateBook(BookDTO book)
        {
            Book newBook = _mapper.Map<Book>(book);
            Book oldBook = _bookRepository.GetBookById(newBook.Id);

            if (oldBook != null)
            {
                _bookRepository.UpdateBook(oldBook, newBook);
            }
            return _mapper.Map<BookDTO>(newBook);
        }

        public bool DeleteBook(int id)
        {
            var bookEntity = _bookRepository.GetBookById(id);


            return _bookRepository.DeleteBook(bookEntity);
        }



    }
}

