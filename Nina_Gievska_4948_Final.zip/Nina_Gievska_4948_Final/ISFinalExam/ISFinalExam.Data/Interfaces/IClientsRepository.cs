﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISFinalExam.Data.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace ISFinalExam.Data.Interfaces
    {
        public interface IClientsRepository
        {
            IEnumerable<IClientsRepository> GetClients();
            IClientsRepository GetClientsById(int id);
            void AddClients(IClientsRepository clients);
            void UpdateClients(IClientsRepository oldClients, IClientsRepository clients);
            bool DeleteClients(IClientsRepository clients);


        }
    }
}

