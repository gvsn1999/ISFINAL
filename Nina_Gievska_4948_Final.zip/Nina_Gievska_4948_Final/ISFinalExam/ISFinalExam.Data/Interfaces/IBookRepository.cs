﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISFinalExam.Data.Interfaces
{
    public interface IBookRepository
    {
        IEnumerable<IBookRepository> GetBooks();
        IBookRepository GetBookById(int id);
        void AddBook(IBookRepository book);
        void UpdateBook(IBookRepository oldBook, IBookRepository books);
        bool DeleteBook(IBookRepository book);
    }
}
