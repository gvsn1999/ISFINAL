﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISFinalExam.Data.Entities;
using ISFinalExam.Data.Interfaces;
using LibraryManagementSystem.Data;

namespace ISFinalExam.Data.Repositories
{


    public class Bookrepository : IBookRepository
    {
        private readonly LibraryContext _dataContext;

        public BookRepository(LibraryContext dataContext)
        {
            _dataContext = dataContext;
        }

        public Book GetBookById(int id)
        {
            return _dataContext.Books.FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Book> GetRooms()
        {
            return _dataContext.Rooms.ToList();
        }

        public void AddBook(Book newbook)
        {
            _dataContext.Books.Add(newbook);
            Save();
        }

        public bool DeleteBook(Book book)
        {
            try
            {
                _dataContext.Books.Remove(book);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void UpdateRoom(Book oldBook, Book newBooks)
        {
            _dataContext.Entry(oldBook).CurrentValues.SetValues(newBooks);
            Save();
        }

        public void Save()
        {
            _dataContext.SaveChangesAsync();
        }






    }
}
