﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISFinalExam.Data.Entities;
using ISFinalExam.Data.Interfaces;

namespace ISFinalExam.Data.Repositories
{
    public class Clientsrepository : Clientsrepository 
    {
        private readonly TrialDataContext _dataContext;

        public ClientsRepository(TrialDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public void AddClients(Clients newclient)
        {
            _dataContext.Clients.Add(newclient);
            Save();
        }

        public bool DeleteClients(Clients clients)
        {
            try
            {
                _dataContext.Clients.Remove(clients);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Clients GetClientsById(int id)
        {
            return _dataContext.Clients.Include(g => g.Room).FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Clients> GetClients()
        {
            return _dataContext.Clients.Include(g => g.Book);
        }

        public void UpdateClient(Clients oldClient, Clients newClients)
        {
            _dataContext.Entry(oldClient).CurrentValues.SetValues(newClients);
            Save();
        }

        public void Save()
        {
            _dataContext.SaveChangesAsync();
        }




    }
}
